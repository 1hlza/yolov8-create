import warnings
import os
warnings.filterwarnings('ignore')
from ultralytics import YOLO

if __name__ == '__main__':
    model = YOLO('D:/AD/yolov8/yolov8-20231031/yolov8-main/ultralytics/cfg/models/v8/yolov8-C2f-DCNV2-Dynamic.yaml')
    model.load('yolov8n.pt') # loading pretrain weights
    model.train(data='D:/AD/yolov8/yolov8-20231031/yolov8-main/dataset/data.yaml',
                cache=False,
                project='runs/train',
                name='yolov8n-new',
                epochs=200,
                batch=6,
                close_mosaic=10,
                 #optimizer='SGD',
                device=0,  # using SGD
                # resume='', # last.pt path
                # amp=False # close amp
                # fraction=0.2
                )
